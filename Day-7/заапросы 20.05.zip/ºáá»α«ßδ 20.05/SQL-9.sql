SELECT  
  bikadamov_user.lastname,
  bikadamov_user.firstname,
  bikadamov_user.patronomic 
  FROM 
    bikadamov_teacher
 INNER JOIN bikadamov_user
    ON bikadamov_teacher.user_id = bikadamov_user.User_id
  INNER JOIN bikadamov_graduate
    ON bikadamov_graduate.user_id = bikadamov_teacher.user_id
  WHERE bikadamov_graduate.user_id IS null