SELECT
  bikadamov_user.lastname,
  bikadamov_user.firstname,
  bikadamov_user.patronomic,
  bikadamov_gruppa.name,
  bikadamov_special.name
  FROM bikadamov_student 

  INNER JOIN bikadamov_user ON bikadamov_student.user_id = bikadamov_user.user_id
  INNER JOIN bikadamov_gruppa ON bikadamov_student.gruppa_id = bikadamov_gruppa.gruppa_id
  INNER JOIN bikadamov_special  ON bikadamov_gruppa.special_id = bikadamov_special.special_id

   WHERE bikadamov_special.special_id=1