SELECT
  bikadamov_gruppa.name, COUNT(*)
FROM  bikadamov_gruppa
  INNER JOIN bikadamov_graduate ON bikadamov_gruppa.gruppa_id=bikadamov_graduate.gruppa_id
GROUP BY bikadamov_gruppa.gruppa_id 