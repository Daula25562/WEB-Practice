SELECT
  bikadamov_otdel.name, COUNT(*)
  FROM bikadamov_student
    INNER JOIN bikadamov_gruppa 
      ON bikadamov_student.gruppa_id = bikadamov_gruppa.gruppa_id
    INNER JOIN bikadamov_special 
      ON bikadamov_gruppa.special_id= bikadamov_special.special_id
    INNER JOIN bikadamov_otdel ON bikadamov_special.otdel_id=bikadamov_otdel.otdel_id
    
    GROUP BY bikadamov_otdel.otdel_id