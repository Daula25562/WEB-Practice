SELECT 
    bikadamov_course.name
FROM 
  bikadamov_graduate
  INNER JOIN bikadamov_course ON bikadamov_graduate.course_id = bikadamov_course.course_id

  WHERE bikadamov_course.special_id IS NULL
