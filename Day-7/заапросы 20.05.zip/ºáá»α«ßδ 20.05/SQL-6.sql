SELECT
  bikadamov_user.lastname,
  bikadamov_user.firstname,
  bikadamov_user.patronomic,
  bikadamov_gruppa.name,
  bikadamov_course.hours,
  bikadamov_course.name
FROM bikadamov_teacher
INNER JOIN bikadamov_user
    ON bikadamov_teacher.user_id = bikadamov_user.User_id
  INNER JOIN bikadamov_graduate
    ON bikadamov_graduate.user_id = bikadamov_teacher.user_id
  INNER JOIN bikadamov_graduate_time
    ON bikadamov_graduate_time.graduate_id = bikadamov_graduate.graduate_id
  INNER JOIN bikadamov_lesson_num
    ON bikadamov_graduate_time.lesson_num_id = bikadamov_lesson_num.lesson_num_id
  INNER JOIN bikadamov_course
    ON bikadamov_graduate.course_id = bikadamov_course.course_id
  INNER JOIN bikadamov_gruppa
    ON bikadamov_graduate.gruppa_id = bikadamov_gruppa.gruppa_id
WHERE bikadamov_lesson_num.time_lesson between '08:30:00' AND '15:00:00'
