SELECT  
  bikadamov_user.lastname, 
  bikadamov_user.firstname,
  bikadamov_user.patronomic,
  bikadamov_gruppa.name,
  bikadamov_course.name
 FROM bikadamov_student

INNER JOIN bikadamov_gruppa
    ON bikadamov_student.gruppa_id = bikadamov_gruppa.gruppa_id
INNER JOIN bikadamov_user
    ON bikadamov_student.user_id = bikadamov_user.User_id
INNER JOIN bikadamov_graduate
    ON bikadamov_graduate.gruppa_id = bikadamov_gruppa.gruppa_id
INNER JOIN bikadamov_course
    ON bikadamov_graduate.course_id = bikadamov_course.course_id
