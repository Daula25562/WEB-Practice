SELECT 
  bikadamov_gruppa.name, 
  bikadamov_gruppa.date_begin, 
  bikadamov_gruppa.date_end
FROM 
  bikadamov_gruppa
Inner Join bikadamov_special ON bikadamov_gruppa.special_id = bikadamov_special.special_id

where bikadamov_special.name = 'Информационные системы'