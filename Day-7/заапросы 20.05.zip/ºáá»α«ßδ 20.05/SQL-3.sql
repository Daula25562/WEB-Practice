SELECT 
  bikadamov_course.name, 
  bikadamov_course.hours, 
  bikadamov_special.name
FROM  
      bikadamov_special
 
INNER JOIN bikadamov_course
    ON bikadamov_course.special_id = bikadamov_special.special_id


 WHERE bikadamov_special.otdel_id = '2'