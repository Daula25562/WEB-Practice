SELECT 
  bikadamov_user.lastname,
  bikadamov_user.firstname,
  bikadamov_user.patronomic,
  bikadamov_gender.name, 
  bikadamov_otdel.name
  FROM bikadamov_user


  INNER JOIN bikadamov_teacher ON bikadamov_user.user_id = bikadamov_teacher.user_id
  INNER JOIN bikadamov_otdel  ON bikadamov_teacher.otdel_id = bikadamov_otdel.otdel_id
  INNER JOIN bikadamov_gender  ON bikadamov_user.gender_id = bikadamov_gender.gender_id

  WHERE bikadamov_otdel.otdel_id=1