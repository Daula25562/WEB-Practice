<?php
class User{
    public $name;
    public $login;
    public $password;

    function showInfo(){
        echo "name: '{$this->name}'; login: '{$this->login}'; password: '{$this->password}';<br>\n";
    }
}

$user1 = new User;
$user1 -> name = "Daulet";
$user1 -> login = "ranger_eg@mail.ru";
$user1 -> password =  "powerRanger15r" ;

$user2 = new User;
$user2 -> name = "Sula";
$user2 -> login = "verN__Jule@gmai.com";
$user2 -> password = "Vsesilnyi23";

$user3 = new User;
$user3 -> name = "Batyr";
$user3 -> login = "Barby_termiT@mail.ru";
$user3 -> password = "redimperaTOR";

$content.=$user1 -> showInfo();
$content.=$user2 -> showInfo();
$content.=$user3 -> showInfo();

?>
