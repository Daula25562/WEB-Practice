<?php

class User{
    public $name;
    public $login;
    public $password;
    function __construct($name,$login,$password){
        $this->name=$name;
        $this->login=$login;
        $this->password=$password;
        echo "Созданный класс'".__CLASS__."'.
      name: '{$this->name}';
      login: '{$this->login}';
      password: '{$this->password}';
      <br>\n";
    }
    function __clone(){
        echo "Клон Класса '".__CLASS__."'.
      name: '{$this->name}';
      login: '{$this->login}';
      password: '{$this->password}';
      <br>\n";
    }
    function __destruct(){
        echo "Удаленный класс '".__CLASS__."'. name: {$this->name};<br>\n";
    }
    function showInfo(){
        echo "Объект класса'".__CLASS__."'.
      name: '{$this->name}';
      login: '{$this->login}';
      password: '{$this->password}';
      <br>\n";
    }
}
$user1 = new User("Daulet","ranger_eg@mail.ru","powerRanger15r");
$user2 = new User("Sula","verN__Jule@gmai.com", "Vsesilnyi23");
$user3 = new User("Batyr","Barby_termiT@mail.ru","redimperaTOR");
$user4 = clone $user1;

unset($user01,$user02,$user03,$user04);



?>
