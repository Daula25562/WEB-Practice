<?php

spl_autoload_register(function($class){
    include "phpClass/$class.class.php";
});
$user1 = new User("Daulet","ranger_eg@mail.ru","powerRanger15r");
$user2 = new User("Sula","verN__Jule@gmai.com", "Vsesilnyi23");
$user3 = new User("Batyr","Barby_termiT@mail.ru","redimperaTOR");

echo "<br>\n";

$user4 = new SuperUser("BrusWayne","BAtMAH_forever","want_to_justice_league","main");
echo "<br>\n";

$user4->showInfo();
echo "<br>\n";

echo "Создан ".User::$countUser." объекст класса User_be<br>\n";
echo "Создан ".SuperUser::$countSuperUser." Объект класса SuperUser_be<br>\n";
echo "<br>\n";

unset($user1,$user2,$user3,$user4);

?>
