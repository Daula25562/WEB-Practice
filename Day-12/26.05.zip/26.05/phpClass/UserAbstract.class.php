<?php

 abstract class UserAbstract{
    abstract function showInfo();
  }


