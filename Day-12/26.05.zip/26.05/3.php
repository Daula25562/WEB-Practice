<?php

class User{
    public $name;
    public $login;
    public $password;
    function __construct($name,$login,$password){
        $this->name=$name;
        $this->login=$login;
        $this->password=$password;
        echo "Созданный класс'".__CLASS__."'.
      name: '{$this->name}';
      login: '{$this->login}';
      password: '{$this->password}';
      <br>\n";
    }
    function __clone(){
        echo "Клон Класса '".__CLASS__."'.
      name: '{$this->name}';
      login: '{$this->login}';
      password: '{$this->password}';
      <br>\n";
    }
    function __destruct(){
        echo "Удаленный класс '".__CLASS__."'. name: {$this->name};<br>\n";
    }
    function showInfo(){
        echo "Объект класса'".__CLASS__."'.
      name: '{$this->name}';
      login: '{$this->login}';
      password: '{$this->password}';
      <br>\n";
    }
}
class SuperUser extends User{
    public $role;

    function __construct($name,$login,$password,$role){
        parent::__construct($name,$login,$password);
        $this->role = $role;
        echo "Cоздан объект класса'".__CLASS__."'.
      role: '{$this->role}';
      <br>\n";
    }

    function showInfo(){
        echo "Объект класса '".__CLASS__."'.
      name: '{$this->name}';
      login: '{$this->login}';
      password: '{$this->password}';
      role: '{$this->role}';
      <br>\n";
    }
}
$user1 = new User("Daulet","ranger_eg@mail.ru","powerRanger15r");
$user2 = new User("Sula","verN__Jule@gmai.com", "Vsesilnyi23");
$user3 = new User("Batyr","Barby_termiT@mail.ru","redimperaTOR");

echo "<br>\n";

$user4 = new SuperUser("BrusWayne","BAtMAH_forever","want_to_justice_league","main");
echo "<br>\n";

$user4->showInfo();
echo "<br>\n";

unset($user1,$user2,$user3,$user4);

?>
