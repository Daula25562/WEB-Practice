<?
header("Cache-control: max-age=600");
//header("Expires: " . date("r")+600);
?>
<!DOCTYPE HTML>

<html>
<head>
	<meta charset="utf-8" />
	<title>Разрешение кеширования</title>
</head>

<body>
<h1>Разрешение кеширования</h1>
<h1><?=date("H:i:s")?></h1>

</body>
</html>
