SELECT bikadamov_special.name
FROM bikadamov_special
Inner Join bikadamov_course ON bikadamov_course.special_id = bikadamov_special.special_id
Inner Join bikadamov_graduate ON bikadamov_graduate.course_id = bikadamov_course.course_id
Inner Join bikadamov_graduate_time ON bikadamov_graduate_time.graduate_id = bikadamov_graduate.graduate_id
Inner Join bikadamov_day ON bikadamov_graduate_time.day_id = bikadamov_day.day_id AND bikadamov_day.name = 'Суббота'