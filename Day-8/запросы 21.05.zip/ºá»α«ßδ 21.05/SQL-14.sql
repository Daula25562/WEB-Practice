SELECT bikadamov_user.user_id, 
  bikadamov_user.lastname, 
  bikadamov_user.firstname
FROM bikadamov_user
Inner Join bikadamov_student ON bikadamov_student.user_id = bikadamov_user.user_id
Inner Join bikadamov_gruppa ON bikadamov_student.gruppa_id = bikadamov_gruppa.gruppa_id
Inner Join bikadamov_graduate ON bikadamov_graduate.gruppa_id = bikadamov_gruppa.gruppa_id
Inner Join bikadamov_graduate_time ON bikadamov_graduate_time.graduate_id = bikadamov_graduate.graduate_id
Inner Join bikadamov_day ON bikadamov_graduate_time.day_id = bikadamov_day.day_id AND bikadamov_day.name = 'Пятница'
