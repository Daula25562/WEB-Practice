SELECT bikadamov_course.course_id, 
       bikadamov_course.name
FROM bikadamov_course
Inner Join bikadamov_graduate ON bikadamov_graduate.course_id = bikadamov_course.course_id
Inner Join bikadamov_graduate_time ON bikadamov_graduate_time.graduate_id = bikadamov_graduate.graduate_id
Inner Join bikadamov_lesson_num ON bikadamov_graduate_time.lesson_num_id = bikadamov_lesson_num.lesson_num_id AND bikadamov_lesson_num.time_lesson BETWEEN '12:30:00' AND '18:30:00'
