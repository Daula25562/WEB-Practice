SELECT *
FROM bikadamov_special
INNER JOIN bikadamov_course ON bikadamov_course.special_id = bikadamov_special.special_id
INNER JOIN bikadamov_graduate ON bikadamov_graduate.course_id = bikadamov_course.course_id
INNER JOIN bikadamov_graduate_time ON bikadamov_graduate_time.graduate_id = bikadamov_graduate.graduate_id
LEFT JOIN bikadamov_day ON (bikadamov_graduate_time.day_id = bikadamov_day.day_id)
LEFT JOIN bikadamov_lesson_num ON (bikadamov_graduate_time.lesson_num_id = bikadamov_lesson_num.lesson_num_id)
WHERE bikadamov_lesson_num.time_lesson BETWEEN '14:00:00' and '18:00:00' AND (bikadamov_day.name = 'Четверг' OR bikadamov_day.name = 'Суббота') AND bikadamov_day.day_id IS NULL AND bikadamov_lesson_num.lesson_num_id IS NULL
