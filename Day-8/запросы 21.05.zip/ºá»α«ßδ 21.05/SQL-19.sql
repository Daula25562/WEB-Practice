SELECT bikadamov_course.name, 
  bikadamov_course.hours, 
  bikadamov_special.name, 
  bikadamov_day.name
FROM bikadamov_otdel 
INNER JOIN bikadamov_special ON bikadamov_special.otdel_id = bikadamov_otdel.otdel_id
INNER JOIN bikadamov_course ON bikadamov_course.special_id = bikadamov_special.special_id
INNER JOIN bikadamov_graduate ON bikadamov_graduate.course_id = bikadamov_course.course_id
INNER JOIN bikadamov_graduate_time ON bikadamov_graduate_time.graduate_id = bikadamov_graduate.graduate_id
INNER JOIN bikadamov_day ON bikadamov_graduate_time.day_id = bikadamov_day.day_id 
WHERE bikadamov_otdel.otdel_id = '2' AND (bikadamov_day.day_id = '3' OR bikadamov_day.day_id = '5')
