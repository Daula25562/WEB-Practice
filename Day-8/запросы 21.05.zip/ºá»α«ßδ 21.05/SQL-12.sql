SELECT  bikadamov_user.user_id, 
        bikadamov_user.lastname, 
        bikadamov_user.firstname
FROM bikadamov_user
Inner Join bikadamov_student ON bikadamov_student.user_id = bikadamov_user.user_id
Inner Join bikadamov_gruppa ON bikadamov_student.gruppa_id = bikadamov_gruppa.gruppa_id
Inner Join bikadamov_graduate ON bikadamov_graduate.gruppa_id = bikadamov_gruppa.gruppa_id
Inner Join bikadamov_graduate_time ON bikadamov_graduate_time.graduate_id = bikadamov_graduate.graduate_id
Inner Join bikadamov_lesson_num ON bikadamov_graduate_time.lesson_num_id = bikadamov_lesson_num.lesson_num_id AND bikadamov_lesson_num.time_lesson BETWEEN '10:30:00' AND '18:30:00' AND bikadamov_user.gender_id='2'
