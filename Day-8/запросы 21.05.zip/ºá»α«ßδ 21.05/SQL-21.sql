SELECT
 bikadamov_day.name, COUNT(*)
 FROM bikadamov_course
 INNER JOIN bikadamov_graduate ON bikadamov_graduate.course_id = bikadamov_course.course_id
 INNER JOIN bikadamov_graduate_time ON bikadamov_graduate_time.graduate_id= bikadamov_graduate.graduate_id
 INNER JOIN bikadamov_day ON bikadamov_graduate_time.day_id = bikadamov_day.day_id
 GROUP BY bikadamov_day.day_id
