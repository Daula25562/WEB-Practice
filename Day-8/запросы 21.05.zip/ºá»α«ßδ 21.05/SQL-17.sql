SELECT bikadamov_user.user_id,
  bikadamov_user.lastname,
  bikadamov_user.firstname,
  bikadamov_otdel.name
FROM bikadamov_user
Inner Join bikadamov_teacher ON bikadamov_teacher.user_id = bikadamov_user.user_id
Inner Join bikadamov_otdel ON bikadamov_teacher.otdel_id = bikadamov_otdel.otdel_id
Inner Join bikadamov_graduate ON bikadamov_graduate.user_id = bikadamov_teacher.user_id
Inner Join bikadamov_graduate_time ON bikadamov_graduate_time.graduate_id = bikadamov_graduate.graduate_id
Inner Join bikadamov_day ON bikadamov_graduate_time.day_id = bikadamov_day.day_id AND bikadamov_day.name = 'Суббота'
