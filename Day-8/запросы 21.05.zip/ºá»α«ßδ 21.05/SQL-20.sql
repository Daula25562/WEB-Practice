SELECT bikadamov_otdel.name
From bikadamov_otdel
Inner Join bikadamov_teacher ON bikadamov_teacher.otdel_id = bikadamov_otdel.otdel_id
Inner Join bikadamov_graduate ON bikadamov_graduate.user_id = bikadamov_teacher.user_id
Inner Join bikadamov_graduate_time ON bikadamov_graduate_time.graduate_id = bikadamov_graduate.graduate_id
Inner Join bikadamov_day ON bikadamov_graduate_time.day_id = bikadamov_day.day_id AND bikadamov_day.name = 'Вторник'
Inner Join bikadamov_lesson_num On bikadamov_graduate_time.lesson_num_id = bikadamov_lesson_num.lesson_num_id AND bikadamov_lesson_num.time_lesson BETWEEN '09:00:00' AND '12:00:00'
