SELECT bikadamov_user.user_id, 
  bikadamov_user.lastname, 
  bikadamov_user.firstname, 
  bikadamov_gruppa.name, 
  bikadamov_special.name
  FROM bikadamov_user
INNER JOIN bikadamov_student ON bikadamov_student.user_id = bikadamov_user.user_id
INNER JOIN bikadamov_gruppa ON bikadamov_gruppa.gruppa_id = bikadamov_student.gruppa_id
INNER JOIN bikadamov_special ON bikadamov_special.special_id = bikadamov_gruppa.special_id
Inner JOIN bikadamov_graduate ON bikadamov_graduate.gruppa_id = bikadamov_gruppa.gruppa_id
INNER JOIN bikadamov_course ON bikadamov_graduate.course_id = bikadamov_course.course_id AND bikadamov_course.hours > '95'
