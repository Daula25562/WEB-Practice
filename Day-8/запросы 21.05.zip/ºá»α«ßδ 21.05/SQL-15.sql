SELECT bikadamov_day.*
FROM bikadamov_day
LEFT JOIN bikadamov_graduate_time ON (bikadamov_day.day_id = bikadamov_graduate_time.day_id)
WHERE bikadamov_graduate_time.graduate_time_id IS NULL