<template>
    <div>
        <h2>Home page</h2>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatum, dolorum! Minus placeat quas dolorem ratione in explicabo atque expedita maiores!</p>
        <router-link to="/todos">Todos</router-link>
    </div>
</template>
<style scoped>

</style>>